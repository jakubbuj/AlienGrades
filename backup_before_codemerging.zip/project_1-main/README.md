# Project_1

# Goals

# Documentation
For maintaing code in clear way we created code architecture diagram.
Link:
https://lucid.app/lucidspark/55b2d80f-9817-4752-aa26-778943c20527/edit?viewport_loc=-3729%2C-2489%2C6161%2C4642%2C0_0&invitationId=inv_13ba1feb-925e-4c69-b328-489e6520d6cd
